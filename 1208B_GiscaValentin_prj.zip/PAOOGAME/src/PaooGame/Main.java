package PaooGame;

public class Main
{
    public static void main(String[] args)
    {
        Game paooGame = new Game("Fiury's Adventures", 960, 640);
        paooGame.StartGame();

    }
}
