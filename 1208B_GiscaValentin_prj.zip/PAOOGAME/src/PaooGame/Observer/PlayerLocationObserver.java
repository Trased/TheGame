package PaooGame.Observer;

public interface PlayerLocationObserver {
    void ObserverUpdate();
}
