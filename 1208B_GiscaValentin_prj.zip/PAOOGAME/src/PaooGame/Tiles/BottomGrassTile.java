package PaooGame.Tiles;

import PaooGame.Graphics.Assets;

public class BottomGrassTile extends Tile
{
    public BottomGrassTile(int id)
    {
        super(Assets.bottomGrass, id);
    }
}