package PaooGame.Tiles;

import PaooGame.Graphics.Assets;
public class SandTile extends Tile {
    public SandTile(int id)
    {
        super(Assets.sand, id);
    }
}
