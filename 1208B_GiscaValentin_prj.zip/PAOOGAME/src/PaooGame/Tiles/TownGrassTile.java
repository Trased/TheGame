package PaooGame.Tiles;

import PaooGame.Graphics.Assets;

public class TownGrassTile extends Tile
{
    public TownGrassTile(int id)
    {
        super(Assets.townGrass, id);
    }
}
